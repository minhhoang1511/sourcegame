﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class HintScript : MonoBehaviour {

    LineRenderer line;

	// Use this for initialization
	void Start () {

    }
	
	// Update is called once per frame
	void Update () {
        line = GetComponent<LineRenderer>();
        line.positionCount = transform.childCount;
        for (int i = 0; i < transform.childCount; i++)
        {
            line.SetPosition(i,transform.GetChild(i).position);
        }
	}

}
