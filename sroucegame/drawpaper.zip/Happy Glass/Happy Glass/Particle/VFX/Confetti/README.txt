Thanks for purchasing my confetti particle systems collection for Unity 3D!

If you haven�t already, import the package into your Unity 3D project by double clicking the .unitypackage file and then click the 'import' button. Make sure all files are selected, the demo scene can be un-ticked if you don�t want to make use of it.

Using the prefabs:

Simply instantiate a prefab into your scene. Each system is set to loop, so when you no longer need the confetti, destroy the instance.

All particle systems are easily editable, including colour, in the inspector and I�d be happy to help if you�re unsure. Just email me! Enjoy!

For any support request please email hi@lukepeek.com

Thank you!

Luke