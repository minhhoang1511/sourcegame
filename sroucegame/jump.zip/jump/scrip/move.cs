
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace game1{
    public class move : MonoBehaviour
    {
        public bool isGrounded;
        public float speed;
        public float jumforce;
        public float jumpvalue;
        public float jumdistan;
        public float jumextra;
        public bool canJump = true;
        public bool isjumpimg = false;
        public float i;
        public bool isMoving = false;
        public PhysicsMaterial2D bound, nomalmat;
        public Animator animator;
        


        public Rigidbody2D ri;

        //private void Awake()
        //{
        //    i = Input.GetAxisRaw("Horizontal");
        //}
        public void run() {
           
            if (!isjumpimg)
            {
                if (Input.GetKey(KeyCode.RightArrow))
                {
                    ri.velocity = new Vector2(i * speed, ri.velocity.y);
                    transform.localScale = new Vector2(1, transform.localScale.y);
                    isMoving = true;
                    animator.SetBool("run", true);

                }
                else if (Input.GetKey(KeyCode.LeftArrow))
                {
                    ri.velocity = new Vector2(i * -speed, ri.velocity.y);
                    transform.localScale = new Vector2(-1, transform.localScale.y);
                    isMoving = true;
                    animator.SetBool("run", true);
                }

                else
                {
                    isMoving = false;
                    animator.SetBool("run", false);
                }
                //ri.velocity = new Vector2(i * speed, ri.velocity.y);



            }



        }
        public void OnCollisionEnter2D(Collision2D col)
        {
            if (col.gameObject.tag == "Ground")
            {
                canJump = true;
                isjumpimg = false;
                //isMoving = false;
                isGrounded = true;
                animator.SetBool("jum", false);
            }
        }
        void OnCollisionExit2D(Collision2D col)
        {
            if (col.gameObject.tag == "Ground")
            {
                isGrounded = false;
                // animator.SetBool("up", false);
            }
        }
        public void jump()
        {
            if (Input.GetMouseButton(0) && canJump && !isMoving)
            {
                
                jumpvalue += Time.deltaTime;
            }
            if (Input.GetMouseButtonUp(0) && canJump && !isjumpimg&& !isMoving)
            {
                if (jumpvalue > 0.25f)
                {
                    Vector2 jumdetrc = transform.up * jumforce;
                    jumdetrc.x = jumpvalue * jumforce;
                    //jumdetrc.x = transform.localScale.x * jumdistan;
                    jumdetrc += Vector2.up * jumpvalue * jumextra;
                    if (transform.localScale.x < 0)
                    {
                        jumdetrc.x *= -1;
                    }
                    ri.AddForce(jumdetrc * jumforce, ForceMode2D.Impulse);
                    isjumpimg = true;
                    animator.SetBool("jum", true);
                }
                jumpvalue = 0f;
            }

            if (jumpvalue>=1.6f)
            {
                //canJump = false;
                jumpvalue = 1.59f;
            }
            
        }
        public void boundd()
        {
            if (jumpvalue > 0)
            {
                ri.sharedMaterial = bound;

            }
            else
            {
                ri.sharedMaterial = nomalmat;
            }
        }
       
       
    }

}




