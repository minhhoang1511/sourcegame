
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class tutorial : MonoBehaviour
{
    public GameObject tutorialText;
    public GameObject tutorialjump; 
    public GameObject back;

    private bool moved = false;
    private void Start()
    {
        tutorialText.SetActive(true);
        tutorialjump.SetActive(false);
        back.SetActive(false);//
    }

    private void Update()
    {
        if (!moved&&(Input.GetKey(KeyCode.RightArrow)||Input.GetKey(KeyCode.LeftArrow)))
        {
            moved = true;
            tutorialText.SetActive(false);
            tutorialjump.SetActive(true); 
        }
        if (Input.GetMouseButton(0) && moved)
        {
            tutorialjump.SetActive(false);
            back.SetActive(true);
        }
    }
}
