
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace game1{
public class ac : move
{
       

    void Start()
    {
         
    animator= GetComponent<Animator>();
    ri= GetComponent<Rigidbody2D>();
    }
    void Update()
    {
         

            this.run();
            this.jump();
            this.boundd();
    }
    


    }
}
