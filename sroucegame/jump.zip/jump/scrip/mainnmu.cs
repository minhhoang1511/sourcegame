using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class mainnmu : MonoBehaviour
{
    public void playgame() {
       // datamanger.instance.Newgame();
        SceneManager.LoadSceneAsync(1);    
    }
    public void quick()
    {
        Application.Quit();
    }
    public void thoat2()
    {
        Application.Quit();
    }


}
