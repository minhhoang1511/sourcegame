using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hs : MonoBehaviour
{
    public Collider2D deathTrigger;
    public float respawnTime = 2f;

    private bool isDead = false;
    Vector2 startpoint;
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "hs")
        {
            isDead = true;
            Die();
        }
    }
    private void Start()
    {
        startpoint = transform.position;
    }

    void Die()
    {
        // Play death animation or sound effect here
        // Set the player's sprite to a dead state

        StartCoroutine(Respawn());
    }

    IEnumerator Respawn()
    {
        yield return new WaitForSeconds(respawnTime);

        isDead = false;
        // Set the player's sprite back to a living state
        transform.position = startpoint; // Set respawn position here
    }
}
