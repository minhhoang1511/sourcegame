using System.Collections;
using System.Collections.Generic;
using UnityEngine;

    public class camerasmooth : MonoBehaviour
    {
    private Transform target;
    private Vector3 veloc = Vector3.zero;
    [Range(0,1)]
    public float smoothSpeed;
    public Vector3 poinoffset;
    private void Awake()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }

    private void FixedUpdate()
    {

        Vector3 desiredPosition = target.position + poinoffset;
        transform.position = Vector3.SmoothDamp(transform.position, desiredPosition,ref veloc, smoothSpeed);
        
    }

}

