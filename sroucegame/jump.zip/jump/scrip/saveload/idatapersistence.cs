using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface idatapersistence 
{
    Vector3 getpoin();
    void setpoins(Vector3 poisition);
 

}
