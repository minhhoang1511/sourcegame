﻿using UnityEngine;

public class sfsf : MonoBehaviour
{
    [SerializeField] private GameObject unitgameobj;
    private sfsf unit;
    private float saveInterval = 2f; // Khoảng thời gian giữa các lần lưu (2 giây)
    private float timer = 0f;
    private void Awake()
    {
        unit = unitgameobj.GetComponent<sfsf>();

    }
    private void Update()
    {
        timer += Time.deltaTime; // Tăng giá trị của biến đếm thời gian

        if (timer >= saveInterval)
        {
            Vector3 playerpoin = unit.GetComponent<Transform>().position; // Gọi hàm lưu dữ liệu
            Debug.Log("" + playerpoin);
            timer = 0f; // Reset lại biến đếm thời gian
        }
    }
}

