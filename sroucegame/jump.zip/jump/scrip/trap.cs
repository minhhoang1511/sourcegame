using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trap : MonoBehaviour
{
    public float force = 10f;
    public Collider2D trapCollider;
    public Collider2D trapDisableCollider;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            if(trapCollider.enabled == true)
            {
                Rigidbody2D playerRb = collision.gameObject.GetComponent<Rigidbody2D>();
                playerRb.AddForce(Vector2.down * force, ForceMode2D.Impulse);

                Rigidbody2D trapRb = GetComponent<Rigidbody2D>();
                trapRb.AddForce(Vector2.down * force, ForceMode2D.Impulse);
            }
            
            trapDisableCollider.enabled = false;
            
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            // 
            trapCollider.enabled = false;
            trapDisableCollider.enabled = true;
        }
    }

}
