﻿namespace MadsBangH.ArcheryGame
{
	public static class Tags
	{
		public const string Player = "Player";
		public const string Target = "Target";
		public const string Arrow = "Arrow";
	}
}