﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace MadsBangH.ArcheryGame
{
    public class h : MonoBehaviour
    {
        private static ArcheryPlayer instance;
        private bool isDead = false; // Sử dụng để kiểm tra xem máu đã về 0 hay chưa

        public int maxhearth = 100;
        public int currenhearth;
        public hearthbar hearthbar;
        //  public ai5 ai;
        [SerializeField]
        private GameObject deathExplosionPrefab = default;


        public void Start()
        {
            currenhearth = maxhearth;
            hearthbar.setmaxhearth(maxhearth);
        }

        // Update is called once per frame
        void Update()
        {

        }
        public void takedame(int dame)
        {
            dool d = gameObject.GetComponent<dool>();
            currenhearth -= dame;
            hearthbar.Sethearth(currenhearth);
            if (currenhearth <= 0 && !isDead)

            {
               
                isDead = true;
                Debug.Log("che");
                //Destroy(gameObject);
                d.toggle(true);
                ArcheryGame.NotifyPlayerWasHit();
                Instantiate(deathExplosionPrefab, transform.position, Quaternion.identity);
                // ai.DeactivateEnemy();
            }
        }

    }
}