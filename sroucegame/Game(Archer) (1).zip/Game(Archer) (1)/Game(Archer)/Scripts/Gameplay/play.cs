﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MadsBangH.ArcheryGame
{
	[RequireComponent(typeof(AudioSource))]
	public class play : MonoBehaviour
	{
		private const float ShotForceMultiplier = 15f;
		private const float ShotForceBase = 3f;
		private const float ReloadCooldownSeconds = 0.5f;
		private const float MinDragDistance = 0.5f;
		private const float MaxDragDistance = 4f;
		private static readonly string StretchAmountParameter = "Stretch Amount";

		//private static readonly int StretchAmountHash = Animator.StringToHash("Stretch Amount");
		[SerializeField]
		public Animator tayAnimator = default;
		[SerializeField]
		private Transform bow = default;
		//[SerializeField]
		//private Transform handTransform = default;
		//[SerializeField]
		//private Transform handTransform1 = default;
		[SerializeField]
		private Animator bowAnimator = default;
		[SerializeField]
		private GameObject arrowOnBow = default;
		[SerializeField]
		private Arrow arrowProjectilePrefab = default;
		[SerializeField]
		private GameObject deathExplosionPrefab = default;

		[SerializeField]
		private AudioClip pull = default;
		[SerializeField]
		private AudioClip shoot = default;

		private bool isPullingBow;
		private float pullStartDistance;
		private bool isReloaded;
		private float lastShotTime;

		private bool allowShooting;
		private AudioSource audioSource;

		private static ArcheryPlayer instance;

		public static Vector2 Position
		{
			get
			{
				if (instance == null)
				{
					instance = FindObjectOfType<ArcheryPlayer>();
					if (instance == null)
					{
						return Vector2.zero;
					}
				}
				return instance.transform.position;
			}
		}

		private void OnEnable()
		{
			ArcheryGame.NewGameStarted += ArcheryGame_NewGameStarted;
			ArcheryGame.GameLost += ArcheryGame_GameLost;
		}

		private void OnDisable()
		{
			ArcheryGame.NewGameStarted -= ArcheryGame_NewGameStarted;
			ArcheryGame.GameLost -= ArcheryGame_GameLost;
		}

		private void ArcheryGame_NewGameStarted()
		{
			allowShooting = true;
		}

		private void ArcheryGame_GameLost()
		{
			allowShooting = false;
		}


		//private void OnTriggerEnter2D(Collider2D collision)
		//{
		//	if (collision.CompareTag(Tags.Target))
		//	{
		//		ArcheryGame.NotifyPlayerWasHit();
		//		Instantiate(deathExplosionPrefab, transform.position, Quaternion.identity);
		//	}
		//}

		private void Update()
		{
			if (!allowShooting)
			{
				isPullingBow = false;
				return;
			}

			// Reload if cooldown has passed
			if (Time.time > lastShotTime + ReloadCooldownSeconds)
			{
				isReloaded = true;
				if (arrowOnBow != null)
				{
					arrowOnBow.SetActive(true);
				}
			}

			// Các xử lý khác ở đây



			Vector3 worldMousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			Vector3 position2D = new Vector2(transform.position.x, transform.position.y);
			Vector2 pullVector = worldMousePosition - position2D; // Thay đổi hướng ở đây
			if (isPullingBow)
			{
				float angle = Mathf.Atan2(pullVector.y, pullVector.x) * Mathf.Rad2Deg;
				float pullMagnitudeDifference = pullVector.magnitude - pullStartDistance;
				float pullAmount = Mathf.Clamp01(Mathf.InverseLerp(MinDragDistance, MaxDragDistance, pullMagnitudeDifference));
				angle = Mathf.Clamp(angle, -55f, 90f);
				UpdateBowGraphics(angle, pullAmount);
				UpdateTayAnimation(pullAmount, angle);
				if (isReloaded && Input.GetMouseButtonUp(0))
				{
					UpdateTayAnimation(0f, angle);
					PerformShot(angle, pullAmount);
					isPullingBow = false;
				}
			}
			else
			{
				if (Input.GetMouseButtonDown(0))
				{
					isPullingBow = true;
					pullStartDistance = pullVector.magnitude;

					audioSource.pitch = UnityEngine.Random.Range(0.9f, 1.1f);
					audioSource.clip = pull;
					audioSource.Play();
				}
			}
		}



		private void UpdateBowGraphics(float angle, float stretchAmount)
		{
			bow.eulerAngles = new Vector3(0f, 0f, angle);
			//handTransform.eulerAngles = new Vector3(0f, 0f, angle);
			//handTransform1.eulerAngles = new Vector3(0f, 0f, angle);

			bowAnimator.SetFloat(StretchAmountParameter, stretchAmount);
		}
		private void UpdateTayAnimation(float stretchAmount, float angle)
		{
			//handTransform.eulerAngles = new Vector3(0f, 0f, angle);
			//handTransform1.eulerAngles = new Vector3(0f, 0f, angle);
			// Update the Stretch Amount parameter in the hand Animator
			tayAnimator.SetFloat(StretchAmountParameter, stretchAmount);
		}
		private void PerformShot(float angle, float stretchAmount)
		{
			isReloaded = false;
			lastShotTime = Time.time;

			arrowOnBow.SetActive(false);
			bowAnimator.SetFloat(StretchAmountParameter, 0f);

			var arrowProjectile = Instantiate(arrowProjectilePrefab);
			float speed = (ShotForceBase + stretchAmount * ShotForceMultiplier);
			arrowProjectile.SetPositionRotationAndSpeed(arrowOnBow.transform.position, angle, speed);

			audioSource.Stop();
			audioSource.pitch = 0.8f + 0.4f * stretchAmount;
			audioSource.PlayOneShot(shoot);
		}
	}
}