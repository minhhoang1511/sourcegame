using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
namespace MadsBangH.ArcheryGame
{
    public class hearthbar : MonoBehaviour
    {
        public Slider slider;
        public void setmaxhearth(int hearth)
        {
            slider.maxValue = hearth;
            slider.value = hearth;
        }
        public void Sethearth(int hearth)
        {
            slider.value = hearth;
        }
    }
}