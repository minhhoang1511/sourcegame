﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace MadsBangH.ArcheryGame
{
    public class dool : MonoBehaviour
    {
        [SerializeField] private List<Collider2D> Collider2D;
        [SerializeField] private List<Rigidbody2D> rigidbody2;
        [SerializeField] private List<Joint2D> joint2D;
        private bool ragdollActive = false;
        // Start is called before the first frame update
        void Start()
        {
            toggle(false);
            // StartCoroutine(ToggleAfterDelay(3f));
        }
        private IEnumerator ToggleAfterDelay(float delay)
        {
            yield return new WaitForSeconds(delay); // Đợi 3 giây
            toggle(true); // Khi đợi xong, thực hiện toggle với giá trị true
        }
        // Update is called once per frame
        public void toggle(bool ragdoll)
        {

            ragdollActive = ragdoll;
            foreach (var col in Collider2D)
            {
                col.enabled = ragdoll;
            }
            foreach (var jont in joint2D)
            {
                jont.enabled = ragdoll;
            }
            foreach (var rb in rigidbody2)
            {
                rb.simulated = ragdoll;
            }
        }
    }
}